<?php

// Set new include path:
ini_set( "include_path" ,ini_get( 'include_path' ) . PATH_SEPARATOR . '/usr/share/mediawiki-extensions/include' );

$mw_debian_extensions_dir = "/etc/mediawiki-extensions/extensions-enabled";

// Including all enabled extensions.
if ( is_dir( $mw_debian_extensions_dir )
   &&
     $dh = opendir( $mw_debian_extensions_dir ) ) {
        while ( ( $file = readdir( $dh ) ) !== false ) {
	    if ( preg_match( "/.php$/",$file ) && is_readable($mw_debian_extensions_dir . DIRECTORY_SEPARATOR . $file) ) {
                include_once( $mw_debian_extensions_dir . DIRECTORY_SEPARATOR . $file );
            }
        }
        closedir( $dh );
     }

?>
