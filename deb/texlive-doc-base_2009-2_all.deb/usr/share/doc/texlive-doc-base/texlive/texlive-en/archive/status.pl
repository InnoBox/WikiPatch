#package: pIq
#license: pd
#(but erasing the headers is not allowed)
#Note that I made the most recent change, but
#Mark Shoulson (shoulson@ctr.columbia.edu)
#wrote the initial version. He should be named 
#in the catalogue, too.

#csuov@csv.warwick.ac.uk
#Subject: cmtt
#To: krab@iesd.auc.dk
#Subject: ftn
#To: inas@MIB.HARZ.DE
#Subject: newthm
#To: reckdahl@leland.stanford.edu
#Subject: epslatex
#To: miktex-bug@ronin.in-berlin.de
#Subject: miktex
#To: de8827@blackjack.usma.edu
#Subject: lated
#To: jdyoung@AFIT.AF.MIL
#Subject: afthesis
#xlwy01@uxp1.hrz.uni-dortmund.de (c2cweb)

$L{"newlfm"}="free-latex";
$L{"pacioli"}="gpl";
$L{"etruscan"}="gpl";
$L{"phoenician"}="gpl";
$L{"greek6bc"}="gpl";
$L{"runic"}="gpl";
1;
